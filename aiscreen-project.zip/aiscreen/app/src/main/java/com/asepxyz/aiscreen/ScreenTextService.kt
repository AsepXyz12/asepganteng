package com.asepxyz.aiscreen

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*
import org.json.JSONObject
import kotlin.math.abs

class ScreenTextService : AccessibilityService() {
    private class Item(val id: Int, val node: AccessibilityNodeInfo, val label: String,
                       val click: Boolean, val edit: Boolean)

    private lateinit var wm: WindowManager
    private val ui = Handler(Looper.getMainLooper())
    private var bubble: TextView? = null
    private var bg: GradientDrawable? = null
    private var card: TextView? = null
    private var panel: View? = null
    private var mode = 0          // 0 = OFF, 1 = ON (jawab saja), 2 = AUTO (jawab + pilih/isi sendiri)
    private var busy = false
    private var seq = 0
    private var lastText = ""
    private var lastReq = 0L
    private var fails = 0
    private val seen = HashSet<String>()      // kalimat soal yang sudah dijawab (angka diganti #, biar timer tidak mengganggu)
    private var lastScrollText = ""
    private var steps = 0
    private var scrollPending = false
    private val cache = HashMap<String, String>()
    private val qRe = Regex(
        "(\\?|^\\s*[A-Ea-e][.)]\\s|\\b(soal|pertanyaan|pilih|jawab|hitung|berapa|siapa|mengapa|" +
            "kenapa|bagaimana|manakah|apakah|isi|which|what|why|how|choose|select|solve|fill)\\b)",
        setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE))
    // tombol final tidak pernah ditekan otomatis, kamu yang tekan sendiri
    private val blocked = Regex("kirim|submit|bayar|beli|hapus|delete|login|masuk|konfirmasi|send|pay|buy|checkout|logout|keluar|selesai|finish",
        RegexOption.IGNORE_CASE)

    override fun onServiceConnected() { wm = getSystemService(WindowManager::class.java); showBubble() }
    override fun onInterrupt() {}

    override fun onUnbind(i: Intent?): Boolean {
        mode = 0; ui.removeCallbacksAndMessages(null)
        bubble?.let { wm.removeView(it) }; card?.let { wm.removeView(it) }; panel?.let { wm.removeView(it) }
        bubble = null; card = null; panel = null
        return super.onUnbind(i)
    }

    private fun key() = getSharedPreferences("s", 0).getString("key", "") ?: ""

    private fun lp(w: Int = WindowManager.LayoutParams.WRAP_CONTENT,
                   flags: Int = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE) =
        WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

    // ---------- baca layar, deteksi soal ----------
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (mode == 0 || e.packageName == packageName) return
        val my = ++seq
        ui.postDelayed({ if (my == seq) check() }, 1000)    // tunggu layar diam 1 detik
    }

    private fun check() {
        if (mode == 0) return
        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: ""
        if (pkg == packageName || pkg == "com.android.systemui") return
        val sb = StringBuilder(); val items = ArrayList<Item>(); collect(root, sb, items, 0)
        val text = sb.toString().trim().take(6000)
        val walk = mode == 3
        val fresh = text.lines().filter { it.length >= 25 }.any { norm(it) !in seen }   // ada soal yang belum dijawab
        if (text.length < 15 || !qRe.containsMatchIn(text) || (walk && !fresh)) { afterScreen(text); return }
        if (similar(text, lastText)) { afterScreen(text); return }
        val auto = mode >= 2
        if (!auto) cache[text]?.let { lastText = text; showCard(it); return }
        if (busy) return
        val wait = 5000 - (System.currentTimeMillis() - lastReq)     // jaga limit key gratis
        if (wait > 0) { val my = seq; ui.postDelayed({ if (my == seq) check() }, wait); return }
        busy = true; lastReq = System.currentTimeMillis(); lastText = text
        showCard("Berpikir...")
        // mode AUTO: kirim daftar elemen bernomor supaya Gemini bisa menunjuk mana yang diklik/diisi
        val isNum = { l: String -> l.length <= 3 && l.all { c -> c.isDigit() } }
        // mode JALAN: buang elemen di atas soal baru (sisa soal sebelumnya yang masih kelihatan) supaya tidak diklik dua kali
        val firstFresh = items.indexOfFirst { it.label.length >= 25 && norm(it.label) !in seen }
        val base = if (walk && firstFresh > 0) items.subList(firstFresh, items.size) else items
        val shown = if (base.count { isNum(it.label) } > 20) base.filter { !isNum(it.label) } else base  // buang kotak nomor soal
        val prompt = if (auto) shown.joinToString("\n") {
            "[${it.id}] ${it.label}" + (if (it.edit) " {isian}" else if (it.click) " {klik}" else "")
        }.take(7000) else "Teks di layar:\n$text"
        val k = key()
        Thread {
            val ans = Gemini.ask(k, prompt, null, true, auto)
            ui.post { busy = false; if (mode != 0) handle(ans, auto, text, items) }
        }.start()
    }

    private fun handle(ans: String, reqAuto: Boolean, text: String, items: List<Item>) {
        if (ans.startsWith("Gagal") || ans.startsWith("API key")) {
            lastText = ""; showCard(ans)
            if (++fails <= 3) ui.postDelayed({ check() }, 8000)   // layar statis tidak memicu event baru, jadi coba lagi sendiri
            return
        }
        fails = 0
        markSeen(text)
        if (!reqAuto) {
            if (ans.trim().equals("SKIP", true)) showCard(null) else { cache[text] = ans; showCard(ans) }
            return
        }
        val j = try { JSONObject(ans.trim().removePrefix("```json").removeSuffix("```").trim()) }
            catch (e: Exception) { null }
        if (j == null) { showCard(ans); afterScreen(text); return }
        if (j.optBoolean("skip")) { showCard(null); afterScreen(text); return }
        val jaw = j.optString("jawaban")
        val acts = j.optJSONArray("aksi")
        showCard(jaw.ifEmpty { null })
        if (mode < 2 || acts == null) { afterScreen(text); return }
        val n = acts.length()
        for (i in 0 until n) {
            val a = acts.getJSONObject(i)
            ui.postDelayed({ if (mode >= 2) act(a, items) }, 600L * i + 300)   // beri jeda tiap aksi
        }
        ui.postDelayed({ afterScreen(text) }, 600L * n + 1500)           // selesai menjawab layar ini, lanjut scroll
    }

    private fun act(a: JSONObject, items: List<Item>) {
        val item = items.firstOrNull { it.id == a.optInt("id", -1) } ?: return
        if (!item.node.refresh()) return                                      // elemen sudah hilang
        if (item.label.length <= 20 && blocked.containsMatchIn(item.label)) return
        when (a.optString("do")) {
            "klik" -> clickNode(item.node)
            "isi" -> if (item.edit) {
                val b = Bundle()
                b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.optString("teks"))
                item.node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
            }
        }
    }

    private fun clickNode(n: AccessibilityNodeInfo) {
        var x: AccessibilityNodeInfo? = n; var i = 0
        while (x != null && i < 5) {                                          // teks sering ada di dalam wadah yang bisa diklik
            if (x.isClickable && x.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            x = x.parent; i++
        }
    }

    private fun canClick(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n; var i = 0
        while (x != null && i < 4) { if (x.isClickable) return true; x = x.parent; i++ }
        return false
    }

    private fun collect(n: AccessibilityNodeInfo?, sb: StringBuilder, items: MutableList<Item>, d: Int) {
        if (n == null || d > 40 || sb.length > 8000) return
        if (n.isVisibleToUser && !n.isPassword) {
            if (n.isEditable) {      // isi kolom ketik tidak dibaca, hanya petunjuknya
                items.add(Item(items.size + 1, n, n.hintText?.toString() ?: n.contentDescription?.toString() ?: "kolom", false, true))
            } else {
                val t = (n.text ?: n.contentDescription)?.toString()?.trim()
                if (!t.isNullOrEmpty()) {
                    sb.append(t).append('\n')
                    items.add(Item(items.size + 1, n, t.take(200), canClick(n), false))
                }
            }
        }
        for (i in 0 until n.childCount) collect(n.getChild(i), sb, items, d + 1)
    }

    private fun norm(s: String) = s.replace(Regex("\\d+"), "#")

    private fun markSeen(text: String) { seen.addAll(text.lines().filter { it.length >= 25 }.map { norm(it) }) }

    // ---------- mode JALAN: scroll sendiri sampai soal habis ----------
    private fun afterScreen(text: String) {
        if (mode != 3 || busy || scrollPending) return
        val n = norm(text)
        if (n == lastScrollText || ++steps > 400) { finish(); return }   // layar tidak bergerak = sudah di bawah
        lastScrollText = n; scrollPending = true
        ui.postDelayed({ scrollPending = false; if (mode == 3) scrollDown() }, 900)
    }

    private fun scrollDown() {
        val root = rootInActiveWindow ?: return
        val list = ArrayList<AccessibilityNodeInfo>(); findScrollable(root, list, 0)
        val best = list.maxByOrNull { val r = Rect(); it.getBoundsInScreen(r); r.width().toLong() * r.height() }
        if (best?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) != true) { finish(); return }
        ui.postDelayed({ check() }, 1300)                                // baca layar setelah scroll
    }

    private fun findScrollable(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, d: Int) {
        if (n == null || d > 40) return
        if (n.isScrollable && n.isVisibleToUser) out.add(n)
        for (i in 0 until n.childCount) findScrollable(n.getChild(i), out, d + 1)
    }

    private fun finish() {
        setMode(0)
        showCard("Selesai: sudah sampai bawah halaman. Periksa jawabanmu, lalu kirim sendiri.")
    }

    private fun similar(a: String, b: String): Boolean {
        // baris pendek (nomor soal 1..160, tombol) diabaikan supaya soal baru tetap terdeteksi
        val x = a.lines().filter { it.length >= 5 }.map { norm(it) }.toSet(); val y = b.lines().filter { it.length >= 5 }.map { norm(it) }.toSet()
        if (y.isEmpty()) return false
        return x.intersect(y).size.toDouble() / x.union(y).size > 0.9
    }

    // ---------- tombol OFF / ON / AUTO + kartu jawaban ----------
    private fun showBubble() {
        val g = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xE6D93025.toInt()) }
        val b = TextView(this).apply {
            text = "OFF"; setTextColor(Color.WHITE); gravity = Gravity.CENTER; textSize = 13f
            background = g; setWidth(150); setHeight(150)
        }
        bg = g; bubble = b
        val p = lp().apply { x = 20; y = 400 }
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false; var held = false
        val hold = Runnable { if (!moved) { held = true; togglePanel() } }
        b.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = p.x; sy = p.y; tx = e.rawX; ty = e.rawY; moved = false; held = false
                    ui.postDelayed(hold, 600)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) { moved = true; ui.removeCallbacks(hold) }
                    p.x = sx + dx; p.y = sy + dy; wm.updateViewLayout(v, p)
                }
                MotionEvent.ACTION_UP -> {
                    ui.removeCallbacks(hold)
                    if (!moved && !held) setMode((mode + 1) % 4)
                }
            }
            true
        }
        wm.addView(b, p)
    }

    private fun setMode(m: Int) {
        mode = m; lastText = ""
        seen.clear(); steps = 0; lastScrollText = ""; scrollPending = false
        bubble?.text = arrayOf("OFF", "ON", "AUTO", "JALAN")[m]
        bg?.setColor(arrayOf(0xE6D93025, 0xE61FA463, 0xE60A84FF, 0xE67B1FA2)[m].toInt())
        if (m > 0) ui.postDelayed({ check() }, 300) else showCard(null)   // langsung cek layar saat ini
    }

    // kartu tembus sentuhan, aplikasi di bawahnya tetap bisa dipakai
    private fun showCard(t: String?) {
        if (t == null) { card?.let { wm.removeView(it) }; card = null; return }
        val c = card ?: TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 15f; setPadding(36, 28, 36, 28); maxLines = 10
            background = GradientDrawable().apply { setColor(0xE6202124.toInt()); cornerRadius = 36f }
            val w = (resources.displayMetrics.widthPixels * 0.92).toInt()
            wm.addView(this, lp(w, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = 180 })
        }.also { card = it }
        c.text = t
    }

    // ---------- panel manual (tahan tombol): tanya bebas / tempel link ----------
    private fun togglePanel() {
        panel?.let { wm.removeView(it); panel = null; return }
        val q = EditText(this).apply {
            hint = "Tanya atau tempel link"; setTextColor(Color.BLACK); setHintTextColor(Color.GRAY)
        }
        val out = TextView(this).apply { setTextColor(Color.BLACK); setTextIsSelectable(true) }
        val row = LinearLayout(this).apply {
            fun btn(t: String, f: () -> Unit) = addView(Button(context).apply {
                text = t; textSize = 12f; setOnClickListener { f() } })
            btn("Tanya") {
                val t = q.text.toString()
                if (t.isBlank()) out.text = "Tulis pertanyaan atau link dulu."
                else { out.text = "Berpikir..."; Thread { val a = Gemini.ask(key(), t, null); ui.post { out.text = a } }.start() }
            }
            btn("X") { togglePanel() }
            btn("Matikan") { disableSelf() }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32)
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = 40f }
            addView(q); addView(row); addView(out)
        }
        val w = (resources.displayMetrics.widthPixels * 0.92).toInt()
        wm.addView(box, lp(w, 0).apply { x = (resources.displayMetrics.widthPixels - w) / 2; y = 200 })
        panel = box
    }
}

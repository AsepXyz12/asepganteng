package com.asepxyz.aiscreen

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

object Gemini {
    // model gratis untuk project baru (cek ai.google.dev/gemini-api/docs/models kalau Google ganti lagi)
    private val geminiModels = listOf("gemini-3.8-flash", "gemini-3.5-flash-lite")
    // cadangan gratis kalau kuota Gemini habis: key Groq berawalan gsk_ (console.groq.com)
    private val groqModels = listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant")

    private const val SYS = "Kamu asisten pintar di tombol melayang. Jawab dalam bahasa pengguna, " +
        "singkat dan langsung. Kalau ada soal atau pertanyaan, beri jawaban lalu alasan " +
        "1-2 kalimat. Kalau ada link, baca isinya dulu sebelum menjawab."
    private const val LIVE = "Kamu menjawab otomatis dari teks yang terbaca di layar HP. Kalau teksnya berisi soal, " +
        "kuis, pertanyaan, atau sesuatu yang butuh jawaban, tulis jawabannya langsung di baris pertama, " +
        "lalu alasan satu kalimat. Abaikan teks menu atau tombol aplikasi. Pakai bahasa yang sama dengan soal. " +
        "Kalau tidak ada yang perlu dijawab, balas persis: SKIP"
    private const val ACT = "Kamu agen yang menjawab soal di layar HP. Input: daftar elemen layar bernomor " +
        "([id] teks {klik} atau {isian}). Kalau ada soal, tentukan jawaban yang benar. Balas JSON saja: " +
        "{\"jawaban\":\"jawaban + alasan satu kalimat\",\"aksi\":[{\"id\":N,\"do\":\"klik\"},{\"id\":N,\"do\":\"isi\",\"teks\":\"...\"}]}. " +
        "Aksi hanya untuk memilih opsi jawaban (klik) atau mengisi kolom jawaban (isi). Pilihan ganda: klik satu opsi " +
        "yang benar; kotak centang: klik semua yang benar. Jangan pernah menekan tombol kirim, submit, lanjut, " +
        "bayar, beli, hapus, atau login. Kalau tidak ada soal, balas {\"skip\":true}"

    fun ask(keyText: String, q: String, bmp: Bitmap?, live: Boolean = false, act: Boolean = false): String {
        val keys = keyText.split(",", "\n", " ").map { it.trim() }.filter { it.isNotEmpty() }
        if (keys.isEmpty()) return "API key belum diisi."
        val sys = if (act) ACT else if (live) LIVE else SYS
        val groqKeys = keys.filter { it.startsWith("gsk_") }
        val gemKeys = keys.filter { !it.startsWith("gsk_") }
        var err = ""
        // rotasi otomatis: tiap model dicoba dengan semua key, lanjut kalau kena limit (429) atau error
        for (m in geminiModels) for (k in gemKeys) {
            val r = post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent",
                mapOf("x-goog-api-key" to k), gemBody(q, bmp, sys, act))
            if (r.first in 200..299) return parseGem(r.second)
            err = "$m HTTP ${r.first}"
        }
        for (m in groqModels) for (k in groqKeys) {
            val r = post("https://api.groq.com/openai/v1/chat/completions",
                mapOf("Authorization" to "Bearer $k"), groqBody(m, q, sys, act))
            if (r.first in 200..299) return parseGroq(r.second)
            err = "$m HTTP ${r.first}"
        }
        return "Gagal ($err). Kuota gratis mungkin habis, coba lagi sebentar atau tambah key lain."
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): Pair<Int, String> = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val t = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        Pair(code, t)
    } catch (e: Exception) { Pair(-1, e.message ?: "error") }

    private fun gemBody(q: String, bmp: Bitmap?, sys: String, act: Boolean): JSONObject {
        val parts = JSONArray().put(JSONObject().put("text", q.ifBlank { "Jawab/jelaskan isi layar ini." }))
        bmp?.let {
            val s = minOf(1f, 1280f / maxOf(it.width, it.height))
            val r = Bitmap.createScaledBitmap(it, (it.width * s).toInt(), (it.height * s).toInt(), true)
            val o = ByteArrayOutputStream(); r.compress(Bitmap.CompressFormat.JPEG, 80, o)
            parts.put(JSONObject().put("inline_data", JSONObject()
                .put("mime_type", "image/jpeg")
                .put("data", Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP))))
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
        // ada link -> aktifkan url_context supaya Gemini membaca halamannya
        if (!act && Regex("https?://\\S+").containsMatchIn(q))
            body.put("tools", JSONArray().put(JSONObject().put("url_context", JSONObject())))
        if (act) body.put("generationConfig", JSONObject().put("responseMimeType", "application/json"))
        return body
    }

    private fun groqBody(m: String, q: String, sys: String, act: Boolean): JSONObject {
        val body = JSONObject().put("model", m).put("messages", JSONArray()
            .put(JSONObject().put("role", "system").put("content", sys))
            .put(JSONObject().put("role", "user").put("content", q.ifBlank { "Halo" })))
        if (act) body.put("response_format", JSONObject().put("type", "json_object"))
        return body
    }

    private fun parseGem(t: String): String {
        val parts = JSONObject(t).optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
            ?: return "Tidak ada jawaban (mungkin diblokir filter)."
        return (0 until parts.length()).mapNotNull {
            parts.getJSONObject(it).optString("text").ifEmpty { null }
        }.joinToString("")
    }

    private fun parseGroq(t: String): String = try {
        JSONObject(t).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    } catch (e: Exception) { "Tidak ada jawaban dari Groq." }
}

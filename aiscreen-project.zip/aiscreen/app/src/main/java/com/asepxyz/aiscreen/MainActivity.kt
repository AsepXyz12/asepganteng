package com.asepxyz.aiscreen

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pref = getSharedPreferences("s", 0)
        val info = TextView(this).apply {
            text = "1. Ambil key gratis di aistudio.google.com/apikey (cadangan: console.groq.com)\n" +
                "2. Tempel di bawah (boleh banyak, pisah koma), lalu simpan\n" +
                "3. Aktifkan \"AI Layar\" di pengaturan Aksesibilitas\n" +
                "4. Tombol bulat muncul di layar: ketuk = ganti OFF / ON (jawab saja) / AUTO (jawab + pilih/isi sendiri) / JALAN (AUTO + scroll sendiri sampai soal habis), tahan = tanya manual"
        }
        val key = EditText(this).apply {
            hint = "API key (Gemini AIza... atau Groq gsk_...), pisah koma"; setText(pref.getString("key", ""))
        }
        val btn = Button(this).apply {
            text = "Simpan key & buka Aksesibilitas"
            setOnClickListener {
                pref.edit().putString("key", key.text.toString().trim()).apply()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48)
            addView(info); addView(key); addView(btn)
        })
    }
}
